deti_coins_cpu_search para WEB ASSEMBLY.

Forma 1:

busybox httpd -p 127.0.0.1:8080 -h ~/Desktop/AAD_2024/P01

Then, open a browser window and enter the URL
http://127.0.0.1:8080/MandelbrotCount.html

Forma 2: mais rapida

python3 -m http.server 8000

escolher o ficheiro web_assembly.html



