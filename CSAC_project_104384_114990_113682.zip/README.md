gcc -Wall -O2 -o deti_coins deti_coins.c
./deti_coins -s9 600